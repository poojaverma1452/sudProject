# Chatbot Fullstack Project

This bundle contains a FastAPI backend and a Vite+React frontend. Follow the README files in each folder to run locally.
