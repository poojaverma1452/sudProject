from pydantic import BaseSettings

class Settings(BaseSettings):
    REQUIRE_API_KEY: bool = False
    API_KEY: str = "dev-key"

settings = Settings()
