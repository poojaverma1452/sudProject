# Simple in-memory mock database for demo purposes.
MOCK_USERS = {
    "user_123": {
        "name": "John Doe",
        "account_number": "XXXX-XXXX-1234",
        "balance": 5234.75,
        "transactions": [
            {"id": "t1", "date": "2025-10-01", "desc": "Grocery", "amount": -45.12},
            {"id": "t2", "date": "2025-09-29", "desc": "Salary", "amount": 2500.00},
            {"id": "t3", "date": "2025-09-20", "desc": "Electricity Bill", "amount": -65.00},
        ],
    }
}

def get_user(user_id: str):
    return MOCK_USERS.get(user_id)
