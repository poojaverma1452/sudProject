from fastapi import FastAPI, HTTPException, Depends, Header
from .schemas import ChatRequest, ChatResponse
from .service import ChatService
from .config import settings

app = FastAPI(title="Secure Chatbot API")
service = ChatService()

def api_key_header(x_api_key: str | None = Header(None)):
    if settings.REQUIRE_API_KEY and x_api_key != settings.API_KEY:
        raise HTTPException(status_code=401, detail="Invalid API key")
    return x_api_key

@app.post("/api/chat", response_model=ChatResponse)
async def chat_endpoint(req: ChatRequest, api_key: str = Depends(api_key_header)):
    try:
        reply = service.handle_message(req.user_id, req.message)
    except PermissionError as e:
        raise HTTPException(status_code=403, detail=str(e))
    return ChatResponse(reply=reply)

@app.get("/api/health")
async def health():
    return {"status": "ok"}
