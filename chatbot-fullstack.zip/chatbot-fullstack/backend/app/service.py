import re
from .db import get_user

BLOCKED_INTENTS = ["transfer", "withdraw", "send money", "wire", "pay someone"]
ALLOW_INTENTS = ["account", "balance", "transactions", "transaction", "history", "statement"]

class ChatService:
    def __init__(self):
        self.blocked_patterns = [re.compile(rf"\b{re.escape(w)}\b", re.I) for w in BLOCKED_INTENTS]
        self.allow_patterns = [re.compile(rf"\b{re.escape(w)}\b", re.I) for w in ALLOW_INTENTS]

    def detect_blocked(self, text: str) -> bool:
        return any(p.search(text) for p in self.blocked_patterns)

    def detect_allow(self, text: str) -> bool:
        return any(p.search(text) for p in self.allow_patterns)

    def handle_message(self, user_id: str, message: str) -> str:
        if self.detect_blocked(message):
            raise PermissionError("I cannot help with fund transfers or withdrawals. For safety, those actions are blocked through this chat.")

        user = get_user(user_id)
        if not user:
            return "I couldn't find your account. Please make sure your user id is correct."

        if self.detect_allow(message):
            if re.search(r"balance|account balance", message, re.I):
                return f"Account holder: {user['name']}\nAccount: {user['account_number']}\nCurrent balance: ${user['balance']:.2f}"
            if re.search(r"transaction|transactions|history|statement", message, re.I):
                txs = user.get("transactions", [])
                lines = [f"{t['date']} | {t['desc']} | ${t['amount']:.2f}" for t in txs]
                return "Recent transactions:\n" + "\n".join(lines) if lines else "No transactions found."

        return "Sorry — I can help with account/balance and transaction history. I cannot perform transfers or withdrawals."
