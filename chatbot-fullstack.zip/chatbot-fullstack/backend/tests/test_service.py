from app.service import ChatService
import pytest

service = ChatService()

def test_block_transfer():
    with pytest.raises(Exception):
        service.handle_message("user_123", "I want to transfer 1000 to user B")

def test_allow_balance():
    resp = service.handle_message("user_123", "What's my account balance?")
    assert "Current balance" in resp
