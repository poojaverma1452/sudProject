# Frontend

Vite + React frontend. From the `frontend/web` folder run `npm install` then `npm run dev`.
