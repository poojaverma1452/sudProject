import React from 'react'
import ChatWindow from './components/ChatWindow'

export default function App(){
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="w-full max-w-3xl bg-white shadow-lg rounded-2xl overflow-hidden">
        <header className="p-4 border-b">
          <h1 className="text-xl font-semibold">SecureBank Chat</h1>
          <p className="text-sm text-gray-500">Ask about account balance or transactions. Transfers/withdrawals are blocked.</p>
        </header>
        <ChatWindow />
      </div>
    </div>
  )
}
