import React, {useState, useRef, useEffect} from 'react'
import MessageBubble from './MessageBubble'

export default function ChatWindow(){
  const [messages, setMessages] = useState([
    {id: 'bot-1', from: 'bot', text: 'Hello! I can show account balance and transaction history. I cannot process transfers or withdrawals.'}
  ])
  const [text, setText] = useState('')
  const listRef = useRef(null)

  useEffect(()=>{ listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: 'smooth' }) }, [messages])

  async function send(){
    if(!text.trim()) return
    const userMessage = {id: `u-${Date.now()}`, from: 'user', text}
    setMessages(m=>[...m, userMessage])
    setText('')

    try{
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ user_id: 'user_123', message: userMessage.text })
      })
      if(res.status === 403){
        const err = await res.json()
        setMessages(m=>[...m, {id:`b-${Date.now()}`, from:'bot', text: err.detail || 'Blocked by policy.'}])
        return
      }
      const data = await res.json()
      setMessages(m=>[...m, {id:`b-${Date.now()}`, from:'bot', text: data.reply}])
    }catch(err){
      setMessages(m=>[...m, {id:`b-${Date.now()}`, from:'bot', text: 'Server error. Please try again later.'}])
    }
  }

  function handleKey(e){ if(e.key === 'Enter') send() }

  return (
    <div className="flex flex-col h-[480px]">
      <div ref={listRef} className="flex-1 overflow-auto p-4 space-y-3">
        {messages.map(m => <MessageBubble key={m.id} from={m.from} text={m.text} />)}
      </div>
      <div className="p-4 border-t flex gap-2">
        <input className="flex-1 rounded-lg border p-2" value={text} onChange={e=>setText(e.target.value)} onKeyDown={handleKey} placeholder="Type your message..." />
        <button className="btn px-4 py-2 bg-blue-600 text-white rounded-lg" onClick={send}>Send</button>
      </div>
    </div>
  )
}
