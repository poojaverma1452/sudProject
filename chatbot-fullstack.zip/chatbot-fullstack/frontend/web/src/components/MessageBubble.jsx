import React from 'react'

export default function MessageBubble({from, text}){
  const isBot = from === 'bot'
  return (
    <div className={`flex ${isBot ? 'justify-start' : 'justify-end'}`}>
      <div className={`${isBot ? 'bg-gray-100 text-gray-900' : 'bg-blue-600 text-white'} max-w-[80%] p-3 rounded-lg`}> 
        <pre className="whitespace-pre-wrap">{text}</pre>
      </div>
    </div>
  )
}
