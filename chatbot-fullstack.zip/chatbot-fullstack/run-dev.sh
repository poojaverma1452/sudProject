#!/usr/bin/env bash

echo 'See backend/README.md and frontend/README.md for run instructions.'
